module.exports.index=function(req,res){
    const username = req.session.username || null;
    const loggedIn = !!username;
    res.render('index', { title: 'Eeshanth Reyhanth', username, loggedIn });
};

module.exports.signin=function(req,res){
    res.render('signin', { title: 'Eeshanth Reyhanth' });
};
module.exports.review=function(req,res){
    res.render('review', { title: 'Eeshanth Reyhanth' });
};