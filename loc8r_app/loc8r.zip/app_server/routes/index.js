var express = require('express'); 
var router = express.Router(); 
var ctrlLocations = require('../controllers/locations'); 
var ctrlothers = require('../controllers/others'); 
var ctrlmain = require('../controllers/main'); 
var ctrlusers = require('../controllers/users');
 
router.get('/', ctrlLocations.homelist); 
router.get('/locations', ctrlLocations.locationInfo); 
router.get('/location1', ctrlLocations.locationInfo1); 
router.get('/location2', ctrlLocations.locationInfo2); 
router.get('/review', ctrlLocations.addReview); 
 
router.get('/about', ctrlothers.about); 
 
router.get('/signin', function(req, res, next) {
    res.render('signin', { title: 'Login', error: null });
});
router.get('/review', ctrlmain.review) 
router.get('/register', function(req, res, next) { 
    res.render('register', { title: 'Register', error: null }); 
});
router.post('/register', ctrlusers.register);

router.get('/signin', ctrlmain.signin);
router.post('/signin', ctrlusers.login);
  
   
module.exports = router;